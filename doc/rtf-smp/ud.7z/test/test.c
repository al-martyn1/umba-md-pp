/*----------------------------------------------------------------------------
*  Module Name:  brsearch.c
*  Description:  Orizon-Navigation Briz searching utilities
*  Date:         02/02/02
*----------------------------------------------------------------------------*/

#ifndef NPLIMPORT
#define NPLIMPORT __declspec(dllexport)
#endif

#pragma hdrstop


#include <string.h>
#include <errno.h>
#include <process.h>

#include <npl.h>
#include <npl.rh>
#include <binr.h>
#include <bitwop.h>

#include "npli.h"


#define  UART_CLOCK_FREQ 1843200 

#define dump(data, len) { for(dmpi=0; dmpi<len; dmpi++) printf("%c", data[dmpi]); printf("\n"); }

/*----------------------------------------------------------------------------*/

#ifdef _WIN32

#include <windows.h>
#include <commctrl.h>

#define BINRPKT_DECLARE_RESET(var_name) \
        binr_reset_pkt var_name = { '\1', '\0', '\1', '\x21', '\1', '\0', '\0' }


/*----------------------------------------------------------------------------*/
extern HINSTANCE hInstance;

static int rates[] = { 110   , 300   , 600   ,  1200,
                       2400  , 4800  , 9600  , 14400,
                       19200 , 38400 , 56000 , 57600,
                       115200, 128000
                     };

#define RATES_COUNT           (sizeof(rates) / sizeof(int))

#define MAX_QSRATE_IDX        12 /* Maximal baud rate for quick search */
#define MIN_QSRATE_IDX         5  /* Minimal baud rate for quick search */

/*----------------------------------------------------------------------------*/
BOOL CALLBACK briz_detect_dlg_proc( HWND hwndDlg, UINT uMsg, 
                                    WPARAM wParam, LPARAM lParam);
unsigned THREADFNCALL breeze_search_thread_proc(void *arg);
unsigned THREADFNCALL breeze_range_search_thread_proc(void *arg);
int NPLCALLBACK breeze_search_notify_proc(void *cbdata, briz_search_notify_struct *bsn);

HANDLE int_win_briz_detect( briz_search_struct *pss, 
                                   HINSTANCE hInst, 
                                   LPCTSTR lpTemplate, 
                                   HWND hwndParent,
                                   DLGPROC lpDialogProc, 
                                   int range);

/*----------------------------------------------------------------------------*/


int NPLCALLBACK on_send( briz_search_struct *bss, 
                   const char* data, int len, 
                   const int flags);
int NPLCALLBACK on_recv_binr( briz_search_struct *bss, 
                   const char* data, int len, 
                   const int flags);
int NPLCALLBACK on_recv_nmea( briz_search_struct *bss, 
                   const char* data, int len, 
                   const int flags);

/*----------------------------------------------------------------------------*/

int NPLAPI nmea_send_req(pproto pp, int level);
int NPLAPI binr_send_req(pproto pp, int level);
int NPLAPI receive_resp( pproto pp, briz_search_struct *pss,
                  int wait_time, COMMTIMEOUTS *cto, int rportion);

/*----------------------------------------------------------------------------*/
NPLIMPORT
HANDLE NPLAPI briz_detect( briz_search_struct *pss)
{
 int start_level;     /* first - quick search */
 int end_level;     
 int level;
 int start_rate_idx, end_rate_idx, rate_idx;
 int maxr[2]     = { MAX_QSRATE_IDX, RATES_COUNT - 1 };
 int minr[2]     = { MIN_QSRATE_IDX, 0 };
 int protocols[2] = { PROTO_BINR, PROTO_NMEA};
 int proto_idx;
 int attempt_num[2][2] = { 4, 6,
                           2, 3
                         };
 int attempt;
 int wait_time[2][2]   = { 60,  400,
                           500, 1000
                         };
 int num_read = 32;

 pproto ppbinr, ppnmea;

 COMMTIMEOUTS cto;
 double sym_time; /* sybmol transmition time */

 if (!pss) { return INVALID_HANDLE_VALUE; } 

 ppbinr =  proto_create( PROTO_BINR, 
                         (proto_event_proc)on_recv_binr, (void*)pss,
                         (proto_event_proc)on_send, (void*)pss);

 ppnmea =  proto_create( PROTO_NMEA, 
                         (proto_event_proc)on_recv_nmea, (void*)pss,
                         (proto_event_proc)on_send, (void*)pss);

 if (!ppbinr || !ppnmea)
    {
     if (ppnmea) proto_delete(ppnmea);
     if (ppbinr) proto_delete(ppbinr);
     /*CloseHandle(pss->hcom);*/
     pss->hcom = INVALID_HANDLE_VALUE;
     return pss->hcom;
    }

 if (pss->search_type & BRIZ_SEARCH_QUICK)
    start_level = 1;
 else
    start_level = 2;

 if (pss->search_type & BRIZ_SEARCH_ADVANCED)
    end_level = 2;
 else
    end_level = 1;

 pss->result = 0;

 cto.WriteTotalTimeoutMultiplier = 0;
 cto.WriteTotalTimeoutConstant = 0;

// printf("start_level: %d, end_level: %d\n", start_level, end_level);

 for ( level = start_level; level<=end_level &&
                            !pss->result; 
       level++ )
     {
//      printf("level: %d\n", level);
      start_rate_idx = maxr[level-1];
      end_rate_idx   = minr[level-1];

      for (proto_idx=0; proto_idx<2 && 
                        !pss->result; 
           proto_idx++)
          {
//           printf("proto_idx: %d,  protocol: %d\n", proto_idx, protocols[proto_idx]);
//           printf("start_rate_idx: %d, end_rate_idx: %d\n", start_rate_idx, end_rate_idx);
           for (rate_idx = start_rate_idx; rate_idx>=end_rate_idx && 
                                           !pss->result; 
                rate_idx--)
               {
//                printf("rate_idx: %d\n", rate_idx);
                pss->protocol = protocols[proto_idx];
                pss->speed    = rates[rate_idx];
                if (UART_CLOCK_FREQ % pss->speed) continue; 
                pss->delay    = wait_time[proto_idx][level-1] * attempt_num[proto_idx][level-1]; 
                pss->search_type = level;
                if (pss->notify_proc && pss->notify_proc(pss->cbdata, (briz_search_notify_struct*)pss))
                   {
                    pss->result |= BRIZ_SEARCH_CANCELED;
                    break;
                   }

                briz_setup_com( pss->hcom, rates[rate_idx], protocols[proto_idx]);

                sym_time = 11.0 / (double)rates[rate_idx];
                /* bits in byte = 11, start + 8bit + parity + stop */          

                /* max interval (ms) = symbol transmit time * 3 *1000 */
                cto.ReadIntervalTimeout = sym_time * 3 * 1000 + 0.5;
                cto.ReadIntervalTimeout = cto.ReadIntervalTimeout 
                                          ? cto.ReadIntervalTimeout 
                                          : 1 ;

                cto.ReadTotalTimeoutMultiplier = sym_time * 1000 + 0.5 + 1;
                cto.ReadTotalTimeoutConstant = 
                                (1000 * sym_time / 2 * num_read + 0.5) + 1;

                pss->reserved = 0;
                proto_clear( protocols[proto_idx]==PROTO_NMEA ? ppnmea : ppbinr, PROTO_CLEAR_RECV);


                for( attempt=0; attempt<attempt_num[proto_idx][level-1] &&
                                !pss->result; 
                     attempt++)
                   {
//                    printf("Attempt #%d\n", attempt);
                    if (protocols[proto_idx]==PROTO_NMEA)
                       nmea_send_req(ppnmea, level);
                    else
                       binr_send_req(ppbinr, level);

                    receive_resp( protocols[proto_idx]==PROTO_NMEA ? ppnmea : ppbinr,
                                  pss, pss->delay/attempt_num[proto_idx][level-1],
                                  &cto, num_read);                   
                   }

               }  /* for (rate_idx = start_rate_idx; rate_idx<=end_rate_idx; rate_idx--) */

          } /* for (proto_idx = 0; proto_idx<2; proto_idx++) */

     } /* for ( level = start_level; level<=end_level; level++ ) */

 proto_delete(ppnmea);
 proto_delete(ppbinr);

 cto.WriteTotalTimeoutMultiplier = 0;
 cto.WriteTotalTimeoutConstant   = 0;
 cto.ReadIntervalTimeout         = 0;
 cto.ReadTotalTimeoutMultiplier  = 0;
 cto.ReadTotalTimeoutConstant    = 0;
 SetCommTimeouts(pss->hcom, &cto);

 if (!(pss->result&BRIZ_SEARCH_OK))
    {
     /*CloseHandle(pss->hcom);*/
     pss->hcom = INVALID_HANDLE_VALUE;
    }
 return pss->hcom;
}
/*----------------------------------------------------------------------------*/
static int NPLAPI nmea_send_req(pproto pp, int level)
{
 int i;
 static char* linktest_quick[] = { 
                                  /* ������� �� ����������� ����������� */
                                  "NPGPQ,GGA", 
//                                  "NPGPQ,GSV", 
//                                  "NPGPQ,RMC",
                                   /* ������� �� ���������� ����������� ������*/
                                  "NPGPQ,PORZE", 
                                  "NPGPQ,PORZX"
                                 };

 static char* linktest_full [] = { 
                                  /* ������� �� ����������� ����������� */
                                  "NPGPQ,GGA", 
                                  "NPGPQ,GSV", 
                                  "NPGPQ,RMC",
                                  "NPGPQ,GSA", 
//                                  "NPGPQ,GLL", 
//                                  "NPGPQ,VTG",
                                  "NPGPQ,ZDA", 
//                                  "NPGPQ,DTM",
                                   /* ������� �� ���������� ����������� ������*/
                                  "NPGPQ,PORZE", 
                                  "NPGPQ,PORZX"
//                                  "NPGPQ,PORZA", 
//                                  "NPGPQ,PORZB", 
//                                  "NPGPQ,PORZD" 
                                 };
// printf("Send NMEA request\n");
 if (level==BRIZ_SEARCH_QUICK)
    {
     for(i=0; i<(sizeof(linktest_quick)/sizeof(char*)); i++)
        {
         proto_send( pp, linktest_quick[i], strlen( linktest_quick[i]));
        }
    }
 else
    {
     for(i=0; i<(sizeof(linktest_full)/sizeof(char*)); i++)
        {
         proto_send( pp, linktest_full[i], strlen( linktest_full[i]));
        }
    }
 return 0;
}
/*----------------------------------------------------------------------------*/
#pragma argsused
static int NPLAPI binr_send_req(pproto pp, int level)
{
 binr_linktest_pkt  linktest = { BINR_LINKTEST_REQUEST };
 binr_port_state_request_pkt portstate = { BINR_PORTSTATE_REQUEST, 0 };
// printf("Send BinR request\n");
 proto_send( pp, (char*)&portstate, sizeof(portstate));
 Sleep(1);
 proto_send( pp, (char*)&linktest, sizeof(linktest));
 return 0;
}
/*----------------------------------------------------------------------------*/
static int NPLAPI receive_resp( pproto pp, briz_search_struct *pss,
                         int wait_time, COMMTIMEOUTS *cto, int rportion)
{
 char   buf[512];
 BOOL   read_res;
 DWORD  readed;
 int i;
 DWORD  stick = GetTickCount();
 DWORD  dt;
 

 rportion = rportion<=sizeof(buf) ? rportion : sizeof(buf);
 SetCommTimeouts(pss->hcom, cto);

// printf("Start receipt\n");


 read_res = ReadFile( pss->hcom, buf, rportion, (LPDWORD)&readed, 0);
// printf("raw: ");
// for (i=0; i<readed; i++) printf("%c", buf[i]);
// printf("\n");

 while( read_res && !pss->result)
   {
//    printf("Receipt loop, readed: %d\n", readed);
    proto_recv( pp, buf, readed);
    dt = GetTickCount() - stick;
    if (((int)dt) > wait_time) 
       {
//        printf("dt: %d, wait_time: %d\n", dt, wait_time);
        break;
       }
    read_res = ReadFile( pss->hcom, buf, rportion, (LPDWORD)&readed, 0);
//    printf("raw: ");
//    for (i=0; i<readed; i++) printf("%c", buf[i]);
//    printf("\n");
   }
 return 0;
}
/*----------------------------------------------------------------------------*/
#pragma argsused
static int NPLCALLBACK on_send( briz_search_struct *bss, 
                          const char* data, int len, 
                          const int flags)
{
 DWORD written;
 WriteFile( bss->hcom, data, len, (LPDWORD)&written, 0); 
 return 0;
}
/*----------------------------------------------------------------------------*/
#pragma argsused
static int NPLCALLBACK on_recv_nmea( briz_search_struct *bss, 
                               const char* data, int len, 
                               const int flags)
{
 static char* pmsg[] = { "PORZA", "PORZB", "PORZD", 
                         "PORZE", "PORZX", "PKON1", "PSSN1" 
                       };
 static char* stdmsg[] = { "GGA", "GSA", "GSV", 
                           "GLL", "RMC", "VTG", 
                           "ZDA", "DTM" 
                         };
 int i, msglen;

 if (!data) return 0;

// printf("nmea: ");
// for (i=0; i<len; i++) printf("%c", data[i]);
// printf("\n");

 for( i=0; i<(sizeof(stdmsg)/sizeof(char*)); i++)
    {
     msglen = strlen(stdmsg[i]);
     if (len<(msglen+2)) continue;
     if (!strncmp(&data[2], stdmsg[i], msglen))
        {
         bss->result |= BRIZ_SEARCH_OK;
         return 1;
        }
    }

 for( i=0; i<(sizeof(pmsg)/sizeof(char*)); i++)
    {
     msglen = strlen(pmsg[i]);
     if (len<(msglen)) continue;
     if (!strncmp(data, pmsg[i], msglen))
        {
         bss->result |= BRIZ_SEARCH_OK;
         return 1;
        }
    }

 return 0;
}
/*----------------------------------------------------------------------------*/
#pragma argsused
static int NPLCALLBACK on_recv_binr( briz_search_struct *bss, 
                               const char* data, int len, 
                               const int flags)
{
 const binr_generic_pkt *response = (const binr_generic_pkt*)data;
 int i;
   
 if (len<=0 || !data) return 0;

// printf("binr: ");
// for (i=0; i<len; i++) printf("%c", data[i]);
// printf("\n");

 if (len == sizeof(binr_linktest_pkt) && response->pktid==BINR_LINKTEST)
    { /* found */
//     printf("BINR_LINKTEST\n");
     bss->reserved ++;
/*     bss->reserved2 += 100; */
     if (bss->reserved>1)
        bss->result |= BRIZ_SEARCH_OK;
        return 1;
    }
 return 0;
}
/*----------------------------------------------------------------------------*/
NPLIMPORT
HANDLE NPLAPI npl_setup_com( HANDLE hcom, int speed, int parity, int *data_bits, int *stop_bits)
{
 DCB dcb;
 if (*data_bits<5) *data_bits = 5;
 if (*data_bits>8) *data_bits = 8;
 if (*data_bits==5 && *stop_bits==TWOSTOPBITS) *stop_bits = ONESTOPBIT;
 if (*data_bits>5 && *stop_bits==ONE5STOPBITS) *stop_bits = ONESTOPBIT;

 dcb.DCBlength=sizeof(DCB); 
 GetCommState(hcom,&dcb);  

 dcb.DCBlength=sizeof(DCB); 
 dcb.BaudRate = speed;
 dcb.fBinary = TRUE;
 dcb.fParity = (parity ? TRUE : FALSE);
 dcb.fOutxCtsFlow = FALSE;     
 dcb.fOutxDsrFlow = FALSE;
 dcb.fDtrControl = DTR_CONTROL_HANDSHAKE; /*DTR_CONTROL_DISABLE;*/
 dcb.fDsrSensitivity = FALSE;
 dcb.fOutX = FALSE;
 dcb.fInX = FALSE;
 dcb.fErrorChar = FALSE;         
 dcb.fNull = FALSE;
 dcb.fRtsControl = RTS_CONTROL_DISABLE;
 dcb.fAbortOnError = FALSE;
 dcb.wReserved = 0;
 dcb.ByteSize = *data_bits;
 dcb.Parity = parity;
 dcb.StopBits = *stop_bits;

 SetCommState(hcom,&dcb);
 return hcom;
}

NPLIMPORT
HANDLE NPLAPI briz_setup_com( HANDLE hcom, int speed, int ptype)
{
 int stop = ONESTOPBIT, data = 8;
 return npl_setup_com( hcom, speed, (ptype==PROTO_BINR ? ODDPARITY : NOPARITY), 
                       &data, &stop);
/*
 DCB dcb;
 dcb.DCBlength=sizeof(DCB); 
 GetCommState(hcom,&dcb);  

 dcb.DCBlength=sizeof(DCB); 
 dcb.BaudRate = speed;
 dcb.fBinary = TRUE;
 dcb.fParity = (ptype==PROTO_BINR ? TRUE : FALSE);
 dcb.fOutxCtsFlow = FALSE;     
 dcb.fOutxDsrFlow = FALSE;
 dcb.fDtrControl = DTR_CONTROL_HANDSHAKE;
 dcb.fDsrSensitivity = FALSE;
 dcb.fOutX = FALSE;
 dcb.fInX = FALSE;
 dcb.fErrorChar = FALSE;         
 dcb.fNull = FALSE;
 dcb.fRtsControl = RTS_CONTROL_DISABLE;
 dcb.fAbortOnError = FALSE;
 dcb.wReserved = 0;
 dcb.ByteSize = 8;
 dcb.Parity = (ptype==PROTO_BINR ? ODDPARITY : NOPARITY);
 dcb.StopBits = ONESTOPBIT;

 SetCommState(hcom,&dcb);
 return hcom;
*/
}
/*----------------------------------------------------------------------------*/
int NPLCALLBACK on_send_setup( HANDLE hcom, 
                               const char* data, int len, 
                               const int flags);
/*----------------------------------------------------------------------------*/
#pragma argsused
static int NPLCALLBACK on_send_setup( HANDLE hcom, 
                                      const char* data, int len, 
                                      const int flags)
{
 DWORD written;
 WriteFile( hcom, data, len, (LPDWORD)&written, 0); 
 return written;
}
/*----------------------------------------------------------------------------*/
int NPLAPI briz_setup( HANDLE hcom, int cur_speed, int cur_proto_type, 
                                       int new_speed, int new_proto_type)
{
 pproto pp;
 binr_port_state_pkt pkt = { BINR_PORTSTATE_SETUP };
 char buf[256];
 DWORD readed;
 COMMTIMEOUTS cto;


 if ((cur_proto_type!=PROTO_BINR && cur_proto_type!=PROTO_NMEA) ||
     (new_proto_type!=PROTO_BINR && new_proto_type!=PROTO_NMEA))
    return -1;
    
 pp = proto_create( cur_proto_type==PROTO_BINR ? PROTO_BINR : PROTO_NMEA,  
                    0, 0, 
                    (proto_event_proc)on_send_setup, (void*)hcom);

 if (!pp) return -1;

 briz_setup_com( hcom, cur_speed, cur_proto_type);

 if (cur_proto_type==PROTO_BINR)
    {
     pkt.port = 0; /* 0 - current */
     pkt.baud_rate = new_speed;
     pkt.protocol = new_proto_type;
     proto_send( pp, (const char*)&pkt, sizeof(pkt));
    }
 else
    {
     wsprintf(buf, "PORZA,0,%d,%d", new_speed, new_proto_type-1);
     proto_send( pp, buf, strlen(buf));
    }
 proto_delete(pp);

 cto.WriteTotalTimeoutMultiplier = 0;
 cto.WriteTotalTimeoutConstant   = 0;
 cto.ReadIntervalTimeout         = 0;
 cto.ReadTotalTimeoutMultiplier  = 2;
 cto.ReadTotalTimeoutConstant    = 512;
 SetCommTimeouts(hcom, &cto);

 ReadFile( hcom, buf, sizeof(buf), (LPDWORD)&readed, 0);

 briz_setup_com( hcom, new_speed, new_proto_type);
 return 0;
}
/*----------------------------------------------------------------------------*/
NPLIMPORT
HANDLE NPLAPI win_briz_detect( briz_search_struct *pss, 
                               HINSTANCE hInst, 
                               LPCTSTR lpTemplate, 
                               HWND hwndParent,
                               DLGPROC lpDialogProc)
{
 return int_win_briz_detect( pss, hInst, lpTemplate, hwndParent, lpDialogProc, 0);
}
/*----------------------------------------------------------------------------*/
NPLIMPORT
HANDLE NPLAPI win_briz_range_search( briz_search_struct *pss, 
                                     HINSTANCE hInst, 
                                     LPCTSTR lpTemplate, 
                                     HWND hwndParent,
                                     DLGPROC lpDialogProc)
{
 return int_win_briz_detect( pss, hInst, lpTemplate, hwndParent, lpDialogProc, 1);
}
/*----------------------------------------------------------------------------*/
HANDLE int_win_briz_detect( briz_search_struct *pss, 
                                   HINSTANCE hInst, 
                                   LPCTSTR lpTemplate, 
                                   HWND hwndParent,
                                   DLGPROC lpDialogProc, 
                                   int range)
{ 
 unsigned thread_id;
 if (!pss) { return INVALID_HANDLE_VALUE; } 
 pss->hwnd_reserved = 0;
 if (!lpDialogProc) lpDialogProc = briz_detect_dlg_proc;
 if (!lpTemplate) lpTemplate = MAKEINTRESOURCE(IDD_BREEZE_SEARCH);
 if (!hInst) hInst = hInstance;
 
 pss->result = 0;

 pss->handle_reserved = (HANDLE) _beginthreadex( 0, 0, /* security attr, stack size are default */
                                                 range ? breeze_range_search_thread_proc 
                                                       : breeze_search_thread_proc,
                                                 (void*)pss, 
                                                  CREATE_SUSPENDED, &thread_id);
 if (!pss->handle_reserved || pss->handle_reserved==(HANDLE)-1) 
             /* � ����� �� BC5.5 �������� ��� ��� 
                ������� ������� = -1, �� ���������� CreateThread,
                � ��� ���������� 0 */
    {
     switch(errno)
       { /* ������ ������� ���������� ������ � errno, �������� �� ������ ���� - 
            � �������� ������ */
        case EAGAIN: SetLastError(ERROR_NO_SYSTEM_RESOURCES); break;
        case ENOMEM: SetLastError(ERROR_NOT_ENOUGH_MEMORY);   break;
        case EINVAL: SetLastError(ERROR_INVALID_DATA); break;
       };
     pss->result |= BRIZ_SEARCH_ERROR;
     return pss->hcom;
    }

// MessageBox(0, "Before", "", 0);
 DialogBoxParam( hInst, lpTemplate, hwndParent, lpDialogProc, (LPARAM)pss);
// MessageBox(0, "After", "", 0);
 return pss->hcom;
}
/*----------------------------------------------------------------------------*/
BOOL CALLBACK briz_detect_dlg_proc( HWND hwndDlg, UINT uMsg, 
                                    WPARAM wParam, LPARAM lParam)
{
 briz_search_struct *pss = 
                    (briz_search_struct*)GetWindowLong(hwndDlg, DWL_USER);
 switch (uMsg)
   {
    case WM_INITDIALOG: 
         SetWindowLong(hwndDlg, DWL_USER, (long) lParam);
         pss = (briz_search_struct*)lParam;
         if (pss->lpposition)
            {
             SetWindowPos( hwndDlg, 0,
                           pss->lpposition->x,
                           pss->lpposition->y,
                           0,0, SWP_NOZORDER | SWP_NOSIZE );  
            }

         Animate_OpenEx( GetDlgItem(hwndDlg,IDC_BSDLG_ANIMATE), 
                         hInstance,
                         MAKEINTRESOURCE(IDA_BREEZE_SEARCH_AVI));
         Animate_Play( GetDlgItem(hwndDlg,IDC_BSDLG_ANIMATE),
                      0, -1, -1 );
         pss->hwnd_reserved = hwndDlg;
         ResumeThread(pss->handle_reserved);

         return TRUE;


    case WM_COMMAND: if (LOWORD(wParam)==IDCANCEL) 
                        pss->result |= BRIZ_SEARCH_CANCELED;
   }
 return FALSE;
}

/*----------------------------------------------------------------------------*/
unsigned THREADFNCALL breeze_search_thread_proc(void *arg)
{
 briz_search_struct *pss = (briz_search_struct*)arg;
 pss->cbdata = arg;
 pss->notify_proc = breeze_search_notify_proc;
 pss->result = 0;
 briz_detect( pss);
 EndDialog(pss->hwnd_reserved, 0);
 return 0;      
}
/*----------------------------------------------------------------------------*/
unsigned THREADFNCALL breeze_range_search_thread_proc(void *arg)
{
 char buf[32];
 int  tmp;
 briz_search_struct *pss = (briz_search_struct*)arg;
 pss->cbdata = arg;
 pss->notify_proc = breeze_search_notify_proc;

 if (pss->first_port > pss->last_port)
    {
     tmp = pss->last_port;
     pss->last_port = pss->first_port;
     pss->first_port = tmp;
    }
 if (pss->first_port<1) pss->first_port = 1;
 if (pss->last_port>256) pss->last_port = 256;
 pss->result = 0;
 
 for( pss->port = pss->first_port; 
      pss->port <= pss->last_port && !pss->result; 
      pss->port++)
    {
     wsprintf(buf, "\\\\.\\COM%d", pss->port);
     pss->hcom = CreateFile( buf, 
                             GENERIC_READ | GENERIC_WRITE, 
                             0, 0,
                             OPEN_EXISTING, 
                             0, 0);
     if (pss->hcom==INVALID_HANDLE_VALUE) continue;
     pss->result = 0;
     briz_detect( pss);
     CloseHandle(pss->hcom);
    }
 
 EndDialog(pss->hwnd_reserved, 0);
 return 0;      
}
/*----------------------------------------------------------------------------*/
#pragma argsused
int NPLCALLBACK breeze_search_notify_proc(void *cbdata, briz_search_notify_struct *bsn)
{
 briz_search_struct *pss = (briz_search_struct*)cbdata;
 char buf[64];

 if (pss->search_type==BRIZ_SEARCH_QUICK)
    {
     ShowWindow( GetDlgItem(pss->hwnd_reserved,IDC_SEARCH_LABEL), SW_HIDE);
     ShowWindow( GetDlgItem(pss->hwnd_reserved,IDC_QUICKSEARCH_LABEL), SW_SHOW);
    }
 else
    {
     ShowWindow( GetDlgItem(pss->hwnd_reserved,IDC_QUICKSEARCH_LABEL), SW_HIDE);
     ShowWindow( GetDlgItem(pss->hwnd_reserved,IDC_SEARCH_LABEL), SW_SHOW);
    }

 wsprintf(buf, "COM%d", pss->port);
 SendMessage( GetDlgItem(pss->hwnd_reserved,IDC_PORT_LABEL), 
              WM_SETTEXT,
              0, (LPARAM)buf);

 wsprintf(buf, "%d", pss->speed);
 SendMessage( GetDlgItem(pss->hwnd_reserved,IDC_BAUD_LABEL),
              WM_SETTEXT,
              0, (LPARAM)buf);

 SendMessage( GetDlgItem(pss->hwnd_reserved,IDC_PROTOCOL_LABEL),
              WM_SETTEXT,
              0, (LPARAM)(pss->protocol==PROTO_NMEA ? "NMEA" : "BinR"));
 return 0;
}


#endif /* _WIN32 */

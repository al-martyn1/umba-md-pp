/*----------------------------------------------------------------------------
*  Module Name:  binr.h
*  Description:  BinR Orizon-Navigation protocol data structures
*  Date:         01/18/02
*----------------------------------------------------------------------------*/


#ifndef BINR_H
#define BINR_H

/*----------------------------------------------------------------------------*/
#ifndef NPL_PROTO_VER_HI
#define NPL_PROTO_VER_HI(ver) ((ver)>>16)
#endif /* NPL_PROTO_VER_HI */
#ifndef NPL_PROTO_VER_LO
#define NPL_PROTO_VER_LO(ver) ((ver)&0xFFFF)
#endif /* NPL_PROTO_VER_LO */
#ifndef NPL_PROTO_MKVER
#define NPL_PROTO_MKVER(hi,lo) ((hi)<<16 | (lo))
#endif /* NPL_PROTO_MKVER */
/*----------------------------------------------------------------------------*/

/* BinR current version 19 */
#ifndef BINR_VER 
#define BINR_VER NPL_PROTO_MKVER(19,0) 
#endif /* BINR_VER */


/*----------------------------------------------------------------------------*/
/* Packets flags */
#define BINRPF_REQUEST       0x01 /* Single request using only packet id */
#define BINRPF_REPORT        0x02 /* Periodic report using standart method */
#define BINRPF_REPORT1S      0x04 /* Report interval only 1 second */
#define BINRPF_REPORT100NS   0x08 /* Report interval in 100 ns */
#define BINRPF_REQUESTPKT    0x10 /* Packet used only for request another 
                                     or for setup */

#define BINRPF_REPSPECMASK   (BINRPF_REPORT1S | BINRPF_REPORT100NS)

#define BINRPF_TFBEQ         0x20 /* works at time-and-freq binding equpment */
#define BINRPF_TBEQ          0x40 /* works at time binding equpment */
#define BINRPF_PMEQ          0x80 
                              /* works at phase meassures supported equpment */

#define BINRPF_SPEQMASK      (BINRPF_TFBEQ | BINRPF_TBEQ | BINRPF_PMEQ)
/*----------------------------------------------------------------------------*/


/*----------------------------------------------------------------------------*/
/* BinR packets IDs */
/*----------------------------------------------------------------------------*/

/* Cancel Transmit */
/* ������ ���� �������� �� �������� */
#define BINR_CANCELTRANSMIT                         0x0E


/*----------------------------------------------------------------------------*/
/* BinR data structs & packets IDs */
/*----------------------------------------------------------------------------*/
#ifndef WORD
#define WORD unsigned short
#endif
#ifndef DWORD
#define DWORD unsigned
#endif
#ifndef BYTE
#define BYTE unsigned char
#endif
#ifndef SHORT_INT
#define SHORT_INT signed short
#endif
#ifndef LONG_INT
#define LONG_INT signed
#endif
#ifndef SHORT_SHORT_INT
#define SHORT_SHORT_INT signed char
#endif

typedef WORD         br_word;
typedef DWORD        br_dword;
typedef BYTE         br_byte;
typedef SHORT_INT    br_short_int, br_short;
typedef LONG_INT     br_long_int, br_long;
typedef SHORT_SHORT_INT br_short_short_int, br_short_short;
typedef float        br_float;
typedef double       br_double;
typedef long double  br_long_double;
/*----------------------------------------------------------------------------*/



#ifdef WIN32
#include <pshpack1.h>
#endif
/*----------------------------------------------------------------------------*/
/* general structs & definitions */

#define BINR_COORDSYS_WGS84            0
#define BINR_COORDSYS_PZ90             1
#define BINR_COORDSYS_SK42             2
#define BINR_COORDSYS_GKSK42           254

#define BINR_SATSYS_GNSS               0
#define BINR_SATSYS_GPS                1
#define BINR_SATSYS_GLONASS            2


/* coordinates struct */
typedef struct tag_binr_coords{
        br_double           latitude;
        br_double           longitude;
        br_double           height;
} binr_coords;

/* serial port params */
typedef struct tag_binr_port_params{
        br_byte             port;        /* 1, 2 */ 
        br_dword            baud_rate;   /* 10 - 115200 */
} binr_port_params;

typedef struct tag_binr_satellite{
        br_byte             system;  /* BINR_SATSYS_*    */
        br_byte             number;  /* 1-32 */
} binr_satellite;

/*----------------------------------------------------------------------------*/

/* Empty packet (without packet body) **/
typedef struct tag_binr_empty_pkt{
        br_byte             pktid;
} binr_empty_pkt, binr_reguest_pkt, binr_generic_pkt, 
  binr_linktest_pkt, binr_linktest_response_pkt; 


/*----------------------------------------------------------------------------*/
/* Rate request packet */
typedef struct tag_binr_rate_pkt{
        br_byte             pktid;
        br_byte             rate;
} binr_rate_pkt;
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/




/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/* System restart */
/* ���������� ������� */
#define BINR_RESET                                  0x01
#define BINR_RESTART                                BINR_RESET

/* int on_reset( int len, const binr_reset_pkt *pkt); */
#define HANDLE_BINR_RESET(buf, len, fn) \
                         (fn)((len), (const binr_reset_pkt*)(buf))
#define HANDLE_BINR_RESTART(buf, len, fn) HANDLE_BINR_RESET(buf, len, fn)


typedef struct tag_binr_reset_pkt{
        br_byte             pktid;
        br_byte             reset_const_data[6];
} binr_reset_pkt, binr_restart_pkt;

/* special const data for reset packet - 01 00 01 21 01 00 00 */
#define BINRPKT_DECLARE_RESET(var_name) \
        binr_reset_pkt var_name = { '\1', '\0', '\1', '\x21', '\1', '\0', '\0' }
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/* Port state */
/* ��������� ����� */
#define BINR_PORTSTATE_SETUP                        0x0B
#define BINR_PORTSTATE_REQUEST                      0x0B
#define BINR_PORTSTATE_RESPONSE                     0x50
#define BINR_PORTSTATE                              0x50

/*int on_port_state(int len, const binr_port_state_pkt* pkt); */
#define HANDLE_BINR_PORTSTATE(buf, len, fn) \
                             (fn)((len), (const binr_port_state_pkt*)(buf))
#define HANDLE_BINR_PORTSTATE_RESPONSE(buf, len, fn) \
        HANDLE_BINR_PORTSTATE(buf, len, fn)

typedef struct tag_binr_port_state_pkt{
        br_byte                     pktid;
        union{
          struct{
                 br_byte            port;        /* 0 - current, 1, 2 */
                 br_dword           baud_rate;   /* 0 - current */
                };
              binr_port_params      port_params;
             };
        br_byte             protocol;    /* use PROTO_* constants */
} binr_port_state_pkt;



typedef struct tag_binr_port_state_request_pkt{
        br_byte                     pktid;
        br_byte                     port;        /* 0 - current, 1, 2 */
} binr_port_state_request_pkt;


#define BINRPKT_DECLARE_PORTSTATE(var_name) \
        binr_port_state_pkt var_name = { '\x0b' }


/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/* System (General) parameters */
/* ��������� ������ ������� (������� ���������, �� �������, ��������� ��) */
#define BINR_GENERAL_PARAMS_SETUP                    0x0D
#define BINR_GENERAL_PARAMS_REQUEST                  BINR_GENERALPARAMS_SETUP
#define BINR_GENERAL_PARAMS                          0x51
#define BINR_GENERAL_PARAMS_RESPONSE                 0x51

/* int on_general_params(int len, const binr_general_params_pkt* pkt); */
#define HANDLE_BINR_GENERAL_PARAMS(buf, len, fn) \
                                 (fn)((len), (const binr_general_params_pkt*)(buf))
#define HANDLE_BINR_GENERAL_PARAMS_RESPONSE(buf, len, fn) \
        HANDLE_BINR_GENERAL_PARAMS(buf, len, fn)


#define BINR_GPTYPE_COORDSYS           1  /* Coordinate system setup */
                                          /* ��������� ������� ��������� */
#define BINR_GPTYPE_SATSYS             2  /* Satellite system setup */
                                          /* ��������� ����������� ������� */
#define BINR_GPTYPE_NTSETUP            3  /* Navigation task setup */
                                          /* ��������� �� */ 
#define BINR_GPTYPE_FILTRATION         4  /* Decision filtration parameters */
                                          /* ��������� ��������� ���������� ������� */

/*-----------------------------------*/
typedef struct tag_binr_general_coordsys{
        br_byte             coord_system; /* BINR_COORDSYS_*  */
} binr_general_coordsys;

typedef struct tag_binr_general_coordsys_pkt{
        br_byte                      pktid;
        br_byte                      type;         /* BINR_GPTYPE_*    */
        union{
              br_byte                coord_system; /* BINR_COORDSYS_*  */
              binr_general_coordsys  coordsys_struct;
             };
} binr_general_coordsys_pkt;

/*-----------------------------------*/
typedef struct tag_binr_general_satsys{
        br_byte             sat_system;   /* BINR_SATSYS_*    */
} binr_general_satsys;

typedef struct tag_binr_general_satsys_pkt{
        br_byte                      pktid;
        br_byte                      type;         /* BINR_GPTYPE_*    */
        union {
               br_byte               sat_system;   /* BINR_SATSYS_*    */
               binr_general_satsys   satsys_struct;
              };
} binr_general_satsys_pkt;

/*-----------------------------------*/
typedef struct tag_binr_general_ntsetup{
        br_byte             min_elevation;  /* graduses */
        br_byte             min_ss;         /* min signal strength */
        br_word             max_rms;        /* max Root-Mean-Square */
                                            /* deviation, meters   */
} binr_general_ntsetup;

typedef struct tag_binr_general_ntsetup_pkt{
        br_byte                   pktid;
        br_byte                   type;           /* BINR_GPTYPE_*    */
        union{
           struct {
                   br_byte        min_elevation;  /* graduses */
                   br_byte        min_ss;         /* min signal strength */
                   br_word        max_rms;        /* max Root-Mean-Square */
                  };                              /* deviation, meters   */
           binr_general_ntsetup   ntsetup_struct;
          };
} binr_general_ntsetup_pkt;

/*-----------------------------------*/
typedef struct tag_binr_general_filt{
        br_float            filtration;   /* 0.0 - off, <1.0 small
                                             1.0 - norm, 1.0-1.2 strong */
} binr_general_filt;

typedef struct tag_binr_general_filt_pkt{
        br_byte             pktid;
        br_byte             type;         /* BINR_GPTYPE_*    */
        union{
              br_float      filtration;   /* 0.0 - off, <1.0 small
                                          1.0 - norm, 1.0-1.2 strong */
              binr_general_filt filt_struct;
             };
} binr_general_filt_pkt;
                                           
/*-----------------------------------*/
/* general params union */
typedef struct tag_binr_ugeneral_params_pkt{
        br_byte             pktid;
        br_byte             type;         /* BINR_GPTYPE_*    */
        union {

               binr_general_coordsys   coordsys_struct;
               br_byte                 coord_system; /* BINR_COORDSYS_*  */

               br_byte                 sat_system;   /* BINR_SATSYS_*    */
               binr_general_satsys     satsys_struct;

               binr_general_ntsetup    ntsetup_struct;
               struct {
                       br_byte         min_elevation; /* graduses */
                       br_byte         min_ss;        /* min signal strength */
                       br_word         max_rms; /* max Root-Mean-Square */
                      };                  /* deviation, meters   */
               binr_general_filt       filt_struct;
               br_float                filtration; /* 0.0 - off, <1.0 small
                                                   1.0 - norm, 1.0-1.2 strong */
              };
} binr_ugeneral_params_pkt;

/*-----------------------------------*/
/* general params - 0x51 */
#define BINR_GPDSTATE_OFF          0  /* Off state */
#define BINR_GPDSTATE_ON           1  /* On state */


typedef struct tag_binr_general_params_pkt{
        br_byte                      pktid;
        union {
               br_byte               sat_system;   /* BINR_SATSYS_*    */
               binr_general_satsys   satsys_struct;
              };
        br_byte                      diff_onoff;   /* 1 - on, 0,4 off, BINR_DPSTATE_* */ 
        union{
              br_byte                coord_system; /* BINR_COORDSYS_*  */
              binr_general_coordsys  coordsys_struct;
             };
        union{
           struct {
                   br_byte           min_elevation;  /* graduses */
                   br_byte           min_ss;         /* min signal strength */
                   br_word           max_rms;        /* max Root-Mean-Square */
                  };                        /* deviation, meters   */
           binr_general_ntsetup      ntsetup_struct;
          };
        union{
              br_float               filtration;   /* 0.0 - off, <1.0 small
                                                   1.0 - norm, 1.0-1.2 strong */
              binr_general_filt      filt_struct;
             };
} binr_general_params_pkt;

/*----------------------------------------------------------------------------*/
/* Diff corrections generation parameters */
/* ��������� ��������� ���� �������� */
#define BINR_DIFF_PARAMS_SETUP                       0x0F
#define BINR_DIFF_PARAMS_REQUEST                     BINR_DIFFPARAMS_SETUP
#define BINR_DIFF_PARAMS_RESPONSE                    0x55
#define BINR_DIFF_PARAMS                             0x55

#define BINR_DPTYPE_PORT            1  /* port params */
                                       /* ��������� ���������� ����� */
#define BINR_DPTYPE_ONOFF           2  /* On or Off state */
                                       /* ���./���������� ������������ */
#define BINR_DPTYPE_COORD           3  /* Set base cordinates */
                                       /* ��������� ��������� */ 

#define BINR_DPSETSTATE_OFF          0  /* Off state */
#define BINR_DPSETSTATE_ON           1  /* On state */

/* int on_diff_params(int len, const binr_diff_params_pkt* pkt); */
#define HANDLE_BINR_DIFF_PARAMS(buf, len, fn) \
                    (fn)((len), (const binr_diff_params_pkt*)(buf))


/*-----------------------------------*/
typedef struct tag_binr_diff_port{
        union{
          struct{
                 br_byte             port;        /* 1, 2 */ 
                 br_dword            baud_rate;   /* 10 - 115200 */
                };
          binr_port_params           port_params;
         };
} binr_diff_port;

typedef struct tag_binr_diff_port_pkt{
        br_byte             pktid;
        br_byte             type;      /* BINR_DPTYPE_PORT */
        union{
          binr_diff_port    port_params;
          struct{
                 br_byte    port;        /* 1, 2 */ 
                 br_dword   baud_rate;   /* 10 - 115200 */
                };
             };
} binr_diff_port_pkt;

/*-----------------------------------*/
typedef struct tag_binr_diff_onoff{
        br_byte             onoff;       /* 1 - on, 0,4 off, BINR_DPSETSTATE_* */ 
} binr_diff_onoff;

typedef struct tag_binr_diff_onoff_pkt{
        br_byte             pktid;
        br_byte             type;      /* BINR_DPTYPE_ONOFF */
        union{
              binr_diff_onoff onoff_struct;
              br_byte         onoff;       /* 1 - on, 0,4 off, BINR_DPSETSTATE_* */     
             };
} binr_diff_onoff_pkt;

/*-----------------------------------*/
typedef binr_coords binr_diff_coords;

typedef struct tag_binr_diff_coords_pkt{
        br_byte             pktid;
        br_byte             type;      /* BINR_DPTYPE_COORD */
        union{
          binr_diff_coords  coords;
          struct{
                 br_double  latitude;
                 br_double  longitude;
                 br_double  height;
                };
             };
} binr_diff_coords_pkt;

/*-----------------------------------*/
typedef struct tag_binr_udiff_params_pkt{
        br_byte                    pktid;
        br_byte                    type;      /* BINR_DPTYPE_* */
        union {
               binr_diff_port      port_params;
               struct {
                       br_byte     port;        /* 1, 2 */ 
                       br_dword    baud_rate;   /* 10 - 115200 */
                      };
               binr_diff_onoff     onoff_struct;
               br_byte             onoff;       /* 1 - on, 0,4 off */ 
               binr_diff_coords    coords;
               struct {
                       br_double   latitude;
                       br_double   longitude;
                       br_double   height;
                      };
              };

} binr_udiff_params_pkt;

/*-----------------------------------*/
/* Diff corrections generation parameters - 0x55 */

#define BINR_DPGETSTATE_OFF          0  /* Off state */
#define BINR_DPGETSTATE_ONREQ        1  /* On state request */
#define BINR_DPGETSTATE_ON           2  /* On state */
#define BINR_DPGETSTATE_OFFREQ       3  /* Off state request */

typedef struct tag_binr_diff_params_pkt{
        br_byte                    pktid;
        union{
              binr_diff_port      port_params;
              struct {
                      br_byte     port;        /* 1, 2 */ 
                      br_dword    baud_rate;   /* 10 - 115200 */
                     };
             };
        union{
              binr_diff_onoff     onoff_struct;
              br_byte             onoff;       /* BINR_DPGETSTATE_* */ 
             };
        union{
              binr_diff_coords    coords;
              struct {
                      br_double   latitude;
                      br_double   longitude;
                      br_double   height;
                     };
             };
} binr_diff_params_pkt;


/*----------------------------------------------------------------------------*/
/* Hardware units test */
/* ���� ����� ���������� */
#define BINR_TEST                                   0x11
#define BINR_TEST_REQUEST                           BINR_TEST
#define BINR_TEST_RESPONSE                          0x43

/* int on_test_response(int len, const binr_test_result_pkt* pkt); */
#define HANDLE_BINR_TEST_RESPONSE(buf, len, fn) \
                    (fn)((len), (const binr_test_result_pkt*)(buf))


#define BINR_TESTTYPE_INITIAL_RESPONSE	 0
#define BINR_TESTTYPE_REQUEST	         1
#define BINR_TESTTYPE_CONFIRM	         BINR_TESTTYPE_REQUEST
#define BINR_TESTTYPE_RESPONSE	         BINR_TESTTYPE_CONFIRM
#define BINR_TESTTYPE_RESULT	         2

/*-----------------------------------*/
typedef struct tag_binr_test_pkt{
        br_byte             pktid;
        br_byte             type; 
} binr_test_pkt, binr_test_confirm_pkt; 

/*-----------------------------------*/
typedef struct tag_binr_test_result_pkt{
        br_byte             pktid;
        br_byte             type; 

        br_byte             cpu:1; 
        br_byte             ram:1; 
        br_byte             rom:1; 
        br_byte             fpu:1; 
        br_byte             reserved:3; 
        br_byte             antenna:1; 

        br_dword            channels;
         
} binr_test_result_pkt; 


/*----------------------------------------------------------------------------*/
/* Satellite use control */
/* ���������� �������������� ��������� */
#define BINR_SAT_USAGECTRL                           0x12
#define BINR_SAT_USAGE                               0x47
#define BINR_SAT_USAGECTRL_RESPONSE                  0x47

/* int on_sat_usage(int len, const binr_satusage_pkt* pkt); */
#define HANDLE_BINR_SAT_USAGE(buf, len, fn) \
                    (fn)((len), (const binr_satusage_pkt*)(buf))


#define BINR_SAT_ENABLED         1
#define BINR_SAT_DISABLED        2

typedef struct tag_binr_satusage{
        union{
          struct{
                 br_byte    sat_system;  /* BINR_SATSYS_*    */
                 br_byte    sat_number;  /* 1-32    */
                };
          binr_satellite    sat;
         };
        br_byte             usage;       /* BINR_SAT_ENABLED, BINR_SAT_DISABLED */
} binr_satusage;

/*-----------------------------------*/

typedef struct tag_binr_satusagectrl_pkt{
        br_byte             pktid;
        union{
          struct{
                 br_byte    sat_system;  /* BINR_SATSYS_*    */
                 br_byte    sat_number;  /* 1-32    */
                 br_byte    usage;       /* BINR_SAT_ENABLED, BINR_SAT_DISABLED */
                };
          binr_satusage     satusage;
         };        
} binr_satusagectrl_pkt; 

/*-----------------------------------*/

typedef struct tag_binr_satusage_pkt{
        br_byte             pktid;
        binr_satusage       usage[56];
} binr_satusage_pkt; 


/*----------------------------------------------------------------------------*/
/* Way angle and speed */
/* ������ �������� ���� � �������� */
#define BINR_WASPEED                                0x41
#define BINR_WASPEED_REQUEST                        0x13
#define BINR_WASPEED_RESPONSE                       0x41

/* int on_waspeed(int len, const binr_waspeed_pkt* pkt); */
#define HANDLE_BINR_WASPEED(buf, len, fn) \
                    (fn)((len), (const binr_waspeed_pkt*)(buf))


typedef binr_rate_pkt binr_warate_pkt;

/*-----------------------------------*/

typedef struct tag_binr_waspeed{
        br_float            cource;
        br_float            speed;
        br_long             time;

} binr_waspeed;

typedef struct tag_binr_waspeed_pkt{
        br_byte             pktid;
        union{
          struct{
                 br_float   cource;
                 br_float   speed;
                 br_long    time;
                };
          binr_waspeed      waspeed;
         };
} binr_waspeed_pkt;

/*----------------------------------------------------------------------------*/
/* Sat receiver state control */
/* ������� ��������� ������� ��������� */
#define BINR_CHAN_STATECTRL                          0x17
#define BINR_CHAN_STATE_REQUEST                      BINR_CHANSTATECTRL        
#define BINR_CHAN_STATECTRL_REQUEST                  BINR_CHANSTATECTRL        
#define BINR_CHAN_STATECTRL_RESPONSE                 0x42
#define BINR_CHAN_STATE                              0x42

/* int on_chan_state(int len, const binr_chanstate_pkt* pkt); */
#define HANDLE_BINR_CHAN_STATE(buf, len, fn) \
                    (fn)((len), (const binr_chanstate_pkt*)(buf))


#define BINR_TRACING_AUTOMATIC             0
#define BINR_TRACING_HANDHELD              1
#define BINR_TRACING_INTEST                2
#define BINR_TRACING_FAIL                  3

#define BINR_CHPRS_AVAIL                     0
#define BINR_CHPRS_FAIL                      1
#define BINR_CHPRS_PARTIAL                   2


typedef struct tag_binr_chanstatectrl{
        union{
          struct{
                 br_byte    sat_system;  /* BINR_SATSYS_*    */
                 br_byte    sat_number;  /* 1-32    */
                };
          binr_satellite    sat;
         };
        br_byte             tracing_mode; 
} binr_chanstatectrl;


typedef struct tag_binr_chanstatectrl_pkt{
        br_byte                   pktid;
        br_byte                   chan_num;    /* 0-13 */
        union{                  
          struct{
                 br_byte          sat_system;  /* BINR_SATSYS_*    */
                 br_byte          sat_number;
                 br_byte          tracing_mode;
                };
          binr_chanstatectrl      chanstate;
        };
} binr_chanstatectrl_pkt;

/*-----------------------------------*/

typedef struct tag_binr_chanstate{
        union{
          struct{
                 br_byte    sat_system;  /* BINR_SATSYS_*    */
                 br_byte    sat_number;  /* 1-32    */
                };
          binr_satellite    sat;
         };
        union{
              br_byte       ss;
              br_byte       signal_strength;
             };
        br_byte             tracing_mode; 
        br_byte             prs;         /* Pseudo-range state (sign) - 
                                            ������� ��������������� */
                                         /* BINR_CHPRS_* */
} binr_chanstate;

typedef struct tag_binr_chanstate_pkt{
        br_byte                   pktid;
        binr_chanstate            chanstates[32];
} binr_chanstate_pkt;


/*----------------------------------------------------------------------------*/
/* Meassures distribution */
/* ������ ��������� */
#define BINR_MEASSURES                              0x48
#define BINR_MEASSURES_REQUEST                      0x18
#define BINR_MEASSURES_RESPONSE                     0x48

/* int on_meassures(int len, const binr_sat_meassures_pkt* pkt); */
#define HANDLE_BINR_MEASSURES(buf, len, fn) \
                    (fn)((len), (const binr_sat_meassures_pkt*)(buf))


typedef binr_rate_pkt binr_measrate_pkt;

/*-----------------------------------*/
/* Meassures - 0x48 */

#define BINR_SMPRS_AVAIL                     255
#define BINR_SMPRS_FAIL                      0
#define BINR_SMPRS_PARTIAL                   1

#define BINR_SMDOPLER_OK                     255
#define BINR_SMDOPLER_NORMAL                 BINR_SMDOPLER_OK
#define BINR_SMDOPLER_FAIL                   0
#define BINR_SMDOPLER_FAIL2                  1


typedef struct tag_binr_sat_meassures{
        br_byte             chan_num;    /* 0-13 */
        union{
          struct{
                 br_byte    sat_system;  /* BINR_SATSYS_*    */
                 br_byte    sat_number;  /* 1-32    */
                };
          binr_satellite    sat;
         };
        br_byte             onboard_number; /* ID(GPS), 
                                               �������� �����(GLONASS)*/
        union{
              br_byte       ss;
              br_byte       signal_strength;
             };
        br_byte             tracing_mode; 
        br_word             ei_state;       /* undocumented ephemerides 
                                               information state flags */
        br_word             prs;            /* Pseudo-range state (sign) - 
                                               ������� ��������������� */
                                            /* BINR_SMPRS_* */
        br_dword            time;           /* �����. ���������, �� */ 
        br_double           range;          /* ���������. �����. 
                                               ���������������, ��*/
        union{
          br_float          est_pr;         /* Estimation pseudo-range 
                                               meassurement */
                                            /* ������ ��������� ��-�����. ��� */
          br_float          range_rms;
         };

        br_word             dopler_state;   /* BINR_SMDOPLER_* */ 
        br_float            dopler;         /* ������������ �������� */
        union{
          br_float          est_dopler;     /* ������ ��������� �������������
                                               ��������� */
          br_float          dopler_rms;
         };
} binr_sat_meassures;

typedef struct tag_binr_sat_meassures_header{
        br_long_double      time;           /* ������� �����. 
                                               �� �� ������ ������ */
        br_short            week;           /* ����� ������ �� 06.01.80 %1024 
                                               <0 - ��� ������ */
        br_long_double      dt_gps;         /* ���������� ������� �� �������� */
        br_long_double      dt_glonass;
        br_float            df_fsrc;        /* ���������� ������� �� 
                                               frequency source delta freq */
} binr_sat_meassures_header;


typedef struct tag_binr_sat_meassures_pkt{
        union{
          struct{
              br_long_double      time;     /* ������� �����. 
                                               �� �� ������ ������ */
              br_short            week;     /* ����� ������ �� 06.01.80 %1024 
                                               <0 - ��� ������ */
              br_long_double      dt_gps;   /* ���������� ������� �� �������� */
              br_long_double      dt_glonass;
              br_float            df_fsrc;  /* ���������� ������� �� 
                                               frequency source delta freq */
             };
          binr_sat_meassures_header    meassures_header;
         };

        binr_sat_meassures             meassures[32];

} binr_sat_meassures_pkt;


/*----------------------------------------------------------------------------*/
/* Ephemerides */
/* ��������� */
#define BINR_EPHEMERIDES                            0x49
#define BINR_EPHEMERIDES_REQUEST                    0x19
#define BINR_EPHEMERIDES_RESPONSE                   0x49

/* int on_ephemerides(int len, const binr_ephemerides_pkt* pkt); */
#define HANDLE_BINR_EPHEMERIDES(buf, len, fn) \
                    (fn)((len), (const binr_ephemerides_pkt*)(buf))


typedef struct tag_binr_ephemerides_request_pkt{
        br_byte             pktid;
        br_byte             sat_system;  /* BINR_SATSYS_*    */
        br_byte             sat_number; 
} binr_ephemerides_request_pkt, binr_noephemerides_pkt;

/*-----------------------------------*/
typedef struct tag_binr_gps_ephemerides{
        br_float            crs;         /* �������� ������� ������ 
                                            (corr. to orbital radius) */
        br_float            Dn;          /* mean motion difference (�������) */
        br_double           M0;          /* ������� �������� (�������)
                                            (mean anomaly) */
        br_float            Cuc;         /* �������� ��������� �������
                                            (corr. to argument of latitude) */
        br_double           E;           /* �������������� (eccentricity) */
        br_float            Cus;         /* �������� ��������� ������
                                            (corr. to argument of latitude) */
        br_double           SqrtA;       /* ����������  ������ ������� ������� 
                                            (square root of semimajor axis) */
        br_double           T0e;         /* ephemeris reference time (����) */
        br_float            Cic;         /* corr. to inclination */
        br_double           Omega0;      /* right ascention parameter 
                                            (�������) */
        br_float            Cis;         /* corr. to inclination */
        br_double           I0;          /* inclination (�������) */
        br_float            Crc;         /* corr. to orbital radius */
        br_double           W;           /* argument of perigee (�������) */
        br_double           OmegaR;      /* rate of right ascention (�������) */
        br_double           Ir;          /* rate of inclination (�������) 
                                            time delay parameters : */
        br_float            Tgd;         /* (��) */
        br_double           T0c;         /* (��) */ 
        br_float            Af2;         /* (��/��**2) */
        br_float            Af1;         /* (��/��) */
        br_float            Af0;         /* (��) */
        br_word             URA;         /* ����������� � ������ */
        br_word             IODE;        /* ������� �� */

} binr_gps_ephemerides;

/*-----------------------------------*/

typedef struct tag_binr_glonass_ephemerides{
        br_byte             sat_liter;

        br_double           X;           /* ���������� (�����) */
        br_double           Y;
        br_double           Z;

        br_double           Vx;          /* �������� (�/��) */
        br_double           Vy;
        br_double           Vz;

        br_double           Ax;          /* ��������� (�/��**2) */
        br_double           Ay;
        br_double           Az;

        br_double           T0e;         /* ���������� ������ � �� �� 
                                            ������ ����� */
        br_float            Gamma;
        br_float            Tau;
        br_word             En;          /* ������� �� */

} binr_glonass_ephemerides;

/*-----------------------------------*/

typedef union tag_binr_ephemerides{
        binr_gps_ephemerides      gps;
        binr_glonass_ephemerides  glonass;
} binr_ephemerides;


typedef struct tag_binr_ephemerides_pkt{
        br_byte             pktid;

        union{
          struct{
                 br_byte    sat_system;  /* BINR_SATSYS_*    */
                 br_byte    sat_number;  /* 1-32    */
                };
          binr_satellite    sat;
         };

        union{
          binr_gps_ephemerides      gps;
          binr_glonass_ephemerides  glonass;
          binr_ephemerides          eph;
         };

} binr_ephemerides_pkt;


/*----------------------------------------------------------------------------*/
/* Frequency Source parameters */
/* ��������� �������� ���������� */
#define BINR_FSPARAMS                               0x71
#define BINR_FSPARAMS_REQUEST                       0x1A
#define BINR_FSPARAMS_RESPONSE                      0x71

/* int on_freqsrc_params(int len, const binr_freqsrc_params_pkt* pkt); */
#define HANDLE_BINR_FSPARAMS(buf, len, fn) \
                    (fn)((len), (const binr_freqsrc_params_pkt*)(buf))


typedef binr_rate_pkt binr_freqsrcparam_rate_pkt;

/*-----------------------------------*/
typedef struct tag_binr_freqsrc_params{         
        br_double           voltage;
        br_float            temperature;
        br_double           av_freq_dev;   /* Average freq deviation */
        br_double           freq_rms;      /* ��� ������� �� ����� ���������� */
        br_long             averaging_period; /* ����� ����������, ��� */
        br_double           last_corr;     /* �������� ��������� ��������� �� */
        br_byte             nsv_gps;       /* ���-�� ������� �� */
        br_byte             nsv_glonass;           
} binr_freqsrc_params;

typedef struct tag_binr_freqsrc_params_pkt{         
        br_byte             pktid;

        union{
          struct{
            br_double       voltage;
            br_float        temperature;
            br_double       av_freq_dev;   /* Average freq deviation */
            br_double       freq_rms;      /* ��� ������� �� ����� ���������� */
            br_long         averaging_period; /* ����� ����������, ��� */
            br_double       last_corr;     /* �������� ��������� ��������� �� */
            br_byte         nsv_gps;       /* ���-�� ������� �� */
            br_byte         nsv_glonass;           
           };
          binr_freqsrc_params freqsrc_params;
         };
} binr_freqsrc_params_pkt;

/*----------------------------------------------------------------------------*/
/* Firmware version */
/* �������������� ������ ��� */
#define BINR_FIRMWAREVER                            0x70
#define BINR_FIRMWAREVER_REQUEST                    0x1B
#define BINR_FIRMWAREVER_RESPONSE                   0x70

/* int on_firmware_version(int len, const binr_firmwarever_pkt* pkt); */
#define HANDLE_BINR_FIRMWAREVER(buf, len, fn) \
                    (fn)((len), (const binr_firmwarever_pkt*)(buf))


/*   comments from A.Shulandt

struct p_70{
 char channel;
 char versys[21];
 unsigned long codesys;
 char vertest[21];
 unsigned long codetest;
 char vermon[21];
 unsigned long codemon;
};

struct code{
 unsigned  sec:6;
 unsigned  hour:5;
 unsigned  day:5;
 unsigned  min:6;
 unsigned  mon:4;
 unsigned  year:6; // +1996
};


code MyCode;
p_70 p_70i;

void UnLink70()
{
 char Var[22];
 fmMain->sgPMO->Cells[1][0]=p_70i.versys;
 memcpy(&MyCode,&p_70i.codesys,4);
 sprintf(Var,"%02d:%02d:%02d, %02d/%02d/%02d",MyCode.hour,MyCode.min,MyCode.sec,MyCode.day,MyCode.mon,MyCode.year+1996);
 fmMain->sgPMO->Cells[2][0]=Var;

 fmMain->sgPMO->Cells[1][1]=p_70i.vertest;
 memcpy(&MyCode,&p_70i.codetest,4);
 sprintf(Var,"%02d:%02d:%02d, %02d/%02d/%02d",MyCode.hour,MyCode.min,MyCode.sec,MyCode.day,MyCode.mon,MyCode.year+1996);
 fmMain->sgPMO->Cells[2][1]=Var;

 fmMain->sgPMO->Cells[1][2]=p_70i.vermon;
 memcpy(&MyCode,&p_70i.codemon,4);
 fmMain->sgPMO->Cells[2][0]=Var;

 fmMain->sgPMO->Cells[1][1]=p_70i.vertest;
 memcpy(&MyCode,&p_70i.codetest,4);
 sprintf(Var,"%02d:%02d:%02d, %02d/%02d/%02d",MyCode.hour,MyCode.min,MyCode.sec,MyCode.day,MyCode.mon,MyCode.year+1996);
 fmMain->sgPMO->Cells[2][1]=Var;

 fmMain->sgPMO->Cells[1][2]=p_70i.vermon;
 memcpy(&MyCode,&p_70i.codemon,4);
 sprintf(Var,"%02d:%02d:%02d, %02d/%02d/%02d",MyCode.hour,MyCode.min,MyCode.sec,MyCode.day,MyCode.mon,MyCode.year+1996);
 fmMain->sgPMO->Cells[2][2]=Var;

 fmMain->sgPMO->Cells[1][3]=IntToStr(p_70i.channel);
}

*/
#define BINR_VERSIONINFO_SIZE                21


typedef struct tag_binr_version_code{
        br_word             second:6;
        br_word             hour:5;
        br_word             day:5;
        br_word             minute:6;
        br_word             month:4;
        br_word             year:6; /* year - 1996 */
} binr_version_code;


typedef struct tag_binr_firmwareversion_info{
        br_byte             chan_count;
        br_byte             sys_ver[BINR_VERSIONINFO_SIZE]; /* module SYSTEM */
        binr_version_code   sys_code;
        br_byte             test_ver[BINR_VERSIONINFO_SIZE];/* module TEST */
        binr_version_code   test_code;
        br_byte             mon_ver[BINR_VERSIONINFO_SIZE]; /* module MONITOR */
        binr_version_code   mon_code;         
} binr_firmwareversion_info;

typedef struct tag_binr_firmwarever_pkt{
        br_byte             pktid;

        union{
          struct{
            br_byte             chan_count;
            br_byte             sys_ver[BINR_VERSIONINFO_SIZE]; /* module SYSTEM */
            binr_version_code   sys_code;
            br_byte             test_ver[BINR_VERSIONINFO_SIZE];/* module TEST */
            binr_version_code   test_code;
            br_byte             mon_ver[BINR_VERSIONINFO_SIZE]; /* module MONITOR */
            binr_version_code   mon_code;         
           };
          binr_firmwareversion_info version_info;
         };
} binr_firmwarever_pkt;

/*----------------------------------------------------------------------------*/
/* Time scale setup */
/* ��������� ����� ������� */
#define BINR_TIMESCALE                              0x1C

#define BINR_TIMESCALE_GLONASS               0
#define BINR_TIMESCALE_GPS                   1
#define BINR_TIMESCALE_UTCSU                 2
#define BINR_TIMESCALE_UTC                   3

typedef struct tag_binr_timescalectrl_pkt{
        br_byte             pktid;
        br_byte             timescale_type; /* BINR_TIMESCALE_* */
} binr_timescalectrl_pkt;

/*----------------------------------------------------------------------------*/
/* Time binding mode */
/* ����� ������ ��������� �������� */
#define BINR_TIMEBIND                               0x73
#define BINR_TIMEBIND_RESPONSE                      0x73
#define BINR_TIMEBIND_SETUP                         0x1D
#define BINR_TIMEBIND_REQUEST                       0x1D

/* int on_timebind(int len, const binr_timebind_pkt* pkt); */
#define HANDLE_BINR_TIMEBIND(buf, len, fn) \
                    (fn)((len), (const binr_timebind_pkt*)(buf))


#define BINR_TBTYPE_COORDMODE                0 /* Coordinates mode - 
                                                * ����� ������ � ������������ */

#define BINR_TBTYPE_SDCOMP                   1 /* Signal delay compensation - 
                                                * ��������� �������� 
                                                * ����������� �������� � 
                                                * �������� ������ ��� 
                                                * ������������ �� � ���� */

#define BINR_TBTYPE_FSCORR                   2 /* Frequency source correction -
                                                * ��������� �������� ���������
                                                * ������� �� � �� */

#define BINR_TBTYPE_MSMODE                   3 /* Master-slave mode - 
                                                * ����� �������-������� */

#define BINR_TBTYPE_TLDEVIATION              4 /* Time label & frequncy 
                                                * source phase - ��������� 
                                                * ���������� �� � ���� �� */

#define BINR_TBTYPE_TLDISCRET                5 /* Time label generation 
                                                * discret - ��������� ��������
                                                * ������������ ��������� 
                                                * ����� */

/* BINR_TBTYPE_COORDMODE */
#define BINR_COORDMODE_DYNAMIC                    0
#define BINR_COORDMODE_FIXED                      1
#define BINR_COORDMODE_WAVERAGING                 2

typedef struct tag_binr_tb_tldeviation{
        br_double           phase_dev;
        br_word             timelabel_dev;
} binr_tb_tldeviation;

/*-----------------------------------*/

typedef struct tag_binr_tbcoordmode_pkt{
        br_byte             pktid;
        br_byte             type;         /* BINR_TBTYPE_COORDMODE */
        br_byte             coordmode;    /* BINR_COORDMODE_* */
} binr_tbcoordmode_pkt;

/*-----------------------------------*/

typedef struct tag_binr_tbsdcompensation_pkt{
        br_byte             pktid;
        br_byte             type;         /* BINR_TBTYPE_SDCOMP */
        br_double           sdcompensation; /* Signal delay compensation */
} binr_tbsdcompensation_pkt;

/*-----------------------------------*/

typedef struct tag_binr_tbfscorrection_pkt{
        br_byte             pktid; 
        br_byte             type;         /* BINR_TBTYPE_FSCORR */
        br_double           fscorrection; /* Frequency source correction */
} binr_tbfscorrection_pkt;

/*-----------------------------------*/

/* BINR_TBTYPE_MSMODE */
#define BINR_MSMODE_AUTONOMUS                0 /* autonomus   */
#define BINR_MSMODE_MASTER                   1 /* master mode */
#define BINR_MSMODE_SLAVE                    2 /* slave mode  */

typedef struct tag_binr_tbmsmode_pkt{
        br_byte             pktid;
        br_byte             type;         /* BINR_TBTYPE_MSMODE */
        br_byte             msmode;       /* BINR_MSMODE_* */
} binr_tbmsmode_pkt;

/*-----------------------------------*/

typedef struct tag_binr_tbtldeviation_pkt{
        br_byte             pktid;
        br_byte             type;         /* BINR_TBTYPE_TLDEVIATION */
        union{
          struct{
            br_double       phase_dev;
            br_word         timelabel_dev;
           };
          binr_tb_tldeviation tld;
         };
        
} binr_tbtldeviation_pkt;

/*-----------------------------------*/

typedef struct tag_binr_tbtldiscret_pkt{
        br_byte             pktid;
        br_byte             type;         /* BINR_TBTYPE_TLDISCRET */
        br_byte             tldiscret;
} binr_tbtldiscret_pkt;

/*-----------------------------------*/
/*
typedef struct tag_binr_timebind_setup_pkt{
        br_byte             pktid;
        br_byte             type;         
        union{
          br_byte             coordmode;    
          br_double           sdcompensation; 
          br_double           fscorrection; 
          br_byte             msmode;
          union{
            struct{
              br_double       phase_dev;
              br_word         timelabel_dev;
             };
            binr_tb_tldeviation tld;        
          };
          br_byte             tldiscret;
        };
} binr_timebind_setup_pkt;
*/
/*-----------------------------------*/

typedef struct tag_binr_timebind{
        br_byte             coordmode;      /* BINR_COORDMODE_* */
        br_double           sdcompensation; /* Signal delay compensation */
        br_word             tldiscret;
} binr_timebind;

typedef struct tag_binr_timebind_pkt{
        br_byte             pktid;
        union{
          struct{
            br_byte         coordmode;      /* BINR_COORDMODE_* */
            br_double       sdcompensation; /* Signal delay compensation */
            br_word         tldiscret;
           };
          binr_timebind     timebind;
         };
} binr_timebind_pkt;


/*----------------------------------------------------------------------------*/
/* Time scale link params */
/* ��������� ����� ���� ������� */
#define BINR_TIMESC_PARAMS                           0x74
#define BINR_TIMESC_PARAMS_REQUEST                   0x1E
#define BINR_TIMESC_PARAMS_RESPONSE                  0x74

/* int on_timescale(int len, const binr_timescale_params_pkt* pkt); */
#define HANDLE_BINR_TIMESC_PARAMS(buf, len, fn) \
                    (fn)((len), (const binr_timescale_params_pkt*)(buf))


typedef union tag_binr_time_reliability{
        br_byte             trel;
        struct{
          br_byte           gps_trel:1;            /* time reliability - */
          br_byte           glonass_trel:1;        /* ������� ������������� */
          br_byte           utc_trel:1;            /* ������� */
          br_byte           utcsu_trel:1;
          br_byte           gps_glonass_trel:1;
        };
} binr_time_reliability;

/*-----------------------------------*/

typedef struct tag_binr_timescale_params{
        br_long_double      gps_deviation;         /* ���� */
        br_long_double      glonass_deviation;     /* ���� */
        br_long_double      gps_utc_delta;         /* ���� */
        br_long_double      glonass_utcsu_delta;   /* ���� */
        br_long_double      gps_glonass_delta;     /* ���� */
        union{
          binr_time_reliability utrel;
          br_byte               btrel;
        };
} binr_timescale_params;

/*-----------------------------------*/

typedef struct tag_binr_timescale_params_pkt{
        br_byte             pktid;
        union{
          struct{
            br_long_double  gps_deviation;         /* ���� */
            br_long_double  glonass_deviation;     /* ���� */
            br_long_double  gps_utc_delta;         /* ���� */
            br_long_double  glonass_utcsu_delta;   /* ���� */
            br_long_double  gps_glonass_delta;     /* ���� */
            union{
              binr_time_reliability utrel;
              br_byte               btrel;
            };
           };
        };
        binr_timescale_params timescale_params;
} binr_timescale_params_pkt;

/*----------------------------------------------------------------------------*/
/* Time and frequency params */
/* ��������� ������� � ������� */
#define BINR_TIMEFREQ                               0x72
#define BINR_TIMEFREQ_REQUEST                       0x1F
#define BINR_TIMEFREQ_RESPONSE                      0x72

/* int on_timefreq(int len, const binr_timefreq_params_pkt* pkt); */
#define HANDLE_BINR_TIMEFREQ(buf, len, fn) \
                    (fn)((len), (const binr_timefreq_params_pkt*)(buf))


typedef binr_rate_pkt binr_timefreq_rate_pkt;


/*-----------------------------------*/

typedef struct tag_binr_timefreq_params{
        br_long_double      time;     /* ������� �����. 
                                       * �� �� ������ ������ */
        br_short            week;     /* ����� ������ �� 06.01.80 %1024 
                                       * <0 - ��� ������ */
        br_byte             timescale_type; /* BINR_TIMESCALE_* */
        br_double           fsrc_deviaton; /* frequency source deviation -
                                            * ������� ������������� ����������
                                            * ������� �� */
        br_double           tl_deviation;  /* time label deviation - 
                                            * ������� ���������� �� �� 
                                            * �������� ����� */
        br_short            gps_leap;
        br_byte             msmode;        /* BINR_MSMODE_* */
        br_word             hardware_state; 
} binr_timefreq_params;

/*-----------------------------------*/

typedef struct tag_binr_timefreq_params_pkt{
        br_byte             pktid;
        union{
          struct{
            br_long_double  time;          /* ������� �����. 
                                            * �� �� ������ ������ */
            br_short        week;          /* ����� ������ �� 06.01.80 %1024 
                                            * <0 - ��� ������ */
            br_byte         timescale_type;/* BINR_TIMESCALE_* */
            br_double       fsrc_deviaton; /* frequency source deviation -
                                            * ������� ������������� ����������
                                            * ������� �� */
            br_double       tl_deviation;  /* time label deviation - 
                                            * ������� ���������� �� �� 
                                            * �������� ����� */
            br_short        gps_leap;
            br_byte         msmode;        /* BINR_MSMODE_* */
            br_word         hardware_state; 
          };
        };
} binr_timefreq_params_pkt;


/*----------------------------------------------------------------------------*/
/* Almanac */
/* �������� */
#define BINR_ALMANAC                                0x40
#define BINR_ALMANAC_REQUEST                        0x20
#define BINR_ALMANAC_RESPONSE                       0x40


/* int on_almanac(int len, const binr_almanac_pkt* pkt); */
#define HANDLE_BINR_ALMANAC(buf, len, fn) \
                    (fn)((len), (const binr_almanac_pkt*)(buf))


#define BINR_SATELLITE_HEALTHY               0


typedef struct tag_binr_gps_almanac{
        br_byte             health;      /* BINR_SATELLITE_HEALTHY |
                                          * !BINR_SATELLITE_HEALTHY */
        br_byte             id;
        br_float            E;           /* Eccentrycity */

        br_float            I0;
        br_float            OmegaR;
        br_double           SqrtA;
        br_float            Omega0;
        br_float            W;
        br_float            M0;
        br_float            Af0m;
        br_float            Af1;
        br_float            Af01;
        br_short            week;
        br_long_double      Time0a;
} binr_gps_almanac;

/*-----------------------------------*/

typedef struct tag_binr_glonass_almanac{
        br_byte             health;      /* BINR_SATELLITE_HEALTHY |
                                          * !BINR_SATELLITE_HEALTHY */
        br_byte             liter;
        br_float            Tau;
        br_float            Lambda;
        br_float            I;
        br_float            E;
        br_float            Omega;
        br_float            Tlambda;
        br_double           Tdr;
        br_float            dTdr;
        br_short            day;
} binr_glonass_almanac;

/*-----------------------------------*/

typedef union tag_binr_almanac{
        binr_gps_almanac      gps;
        binr_glonass_almanac  glonass;
} binr_almanac;

/*-----------------------------------*/

typedef struct tag_binr_almanac_pkt{
        br_byte             pktid;
        union{
          struct{
                 br_byte    sat_system;  /* BINR_SATSYS_*    */
                 br_byte    sat_number;  /* 1-32    */
                };
          binr_satellite    sat;
         };
        union{
          binr_gps_almanac      gps;
          binr_glonass_almanac  glonass;
          binr_almanac          almanac;
         };

} binr_almanac_pkt;

/*-----------------------------------*/

typedef struct tag_binr_gps_almanac_pkt{
        br_byte             pktid;
        union{
          struct{
                 br_byte    sat_system;  /* BINR_SATSYS_*    */
                 br_byte    sat_number;  /* 1-32    */
                };
          binr_satellite    sat;
         };
        union{
          struct{
            br_byte             health;      /* BINR_SATELLITE_HEALTHY |
                                              * !BINR_SATELLITE_HEALTHY */
            br_byte             id;
            br_float            E;           /* Eccentrycity */
    
            br_float            I0;
            br_float            OmegaR;
            br_double           SqrtA;
            br_float            Omega0;
            br_float            W;
            br_float            M0;
            br_float            Af0m;
            br_float            Af1;
            br_float            Af01;
            br_short            week;
            br_long_double      Time0a;
           };
          binr_gps_almanac      almanac;
         };
} binr_gps_almanac_pkt;

/*-----------------------------------*/

typedef struct tag_binr_glonass_almanac_pkt{
        br_byte             pktid;
        union{
          struct{
                 br_byte    sat_system;  /* BINR_SATSYS_*    */
                 br_byte    sat_number;  /* 1-32    */
                };
          binr_satellite    sat;
         };
        union{
          struct{
            br_byte             health;      /* BINR_SATELLITE_HEALTHY |
                                              * !BINR_SATELLITE_HEALTHY */
            br_byte             liter;
            br_float            Tau;
            br_float            Lambda;
            br_float            I;
            br_float            E;
            br_float            Omega;
            br_float            Tlambda;
            br_double           Tdr;
            br_float            dTdr;
            br_short            day;
           };
          binr_glonass_almanac  almanac;
         };
} binr_glonass_almanac_pkt;

/*-----------------------------------*/

typedef struct tag_binr_almanac_request_pkt{
        br_byte             pktid;
        union{
          struct{
                 br_byte    sat_system;  /* BINR_SATSYS_*    */
                 br_byte    sat_number;  /* 1-32    */
                };
          binr_satellite    sat;
         };
} binr_almanac_request_pkt;


/*----------------------------------------------------------------------------*/
/* Used SV */
/* ������������(�������) �� */
#define BINR_USEDSV                                 0x60
#define BINR_USEDSV_REQUEST                         0x21
#define BINR_USEDSV_RESPONSE                        0x60

/* int on_usedsv(int len, const binr_usedsv_pkt* pkt); */
#define HANDLE_BINR_USEDSV(buf, len, fn) \
                    (fn)((len), (const binr_usedsv_pkt*)(buf))


typedef binr_rate_pkt binr_usedsv_rate_pkt;

/*-----------------------------------*/

typedef struct tag_binr_usedsv_info{
        br_byte             nsv_gps;
        br_byte             nsv_glonass;
        br_float            HDOP;
        br_float            VDOP;
} binr_usedsv_info;

/*-----------------------------------*/

typedef struct tag_binr_usedsv_pkt{
        br_byte             pktid;
        union{
          struct{
            br_byte         nsv_gps;
            br_byte         nsv_glonass;
            br_float        HDOP;
            br_float        VDOP;
          };
          binr_usedsv_info  usedsv;
        };
} binr_usedsv_pkt;


/*----------------------------------------------------------------------------*/
/* Time zone */
/* ������� ����� */
#define BINR_TIMEZONE_SETUP                         0x23
#define BINR_TIMEZONE_REQUEST                       0x23
#define BINR_TIMEZONE                               0x46
#define BINR_TIMEZONE_RESPONSE                      0x46
#define BINR_DATETIME                               BINR_TIMEZONE_RESPONSE

/* int on_datetime(int len, const binr_datetime_pkt* pkt); */
#define HANDLE_BINR_DATETIME(buf, len, fn) \
                    (fn)((len), (const binr_datetime_pkt*)(buf))
#define HANDLE_BINR_TIMEZONE(buf, len, fn) \
                    HANDLE_BINR_DATETIME(buf, len, fn)

typedef struct tag_binr_timezone_info{
        br_short_short      hour_bias;
        br_short_short      minutes_bias;
} binr_timezone_info;

/*-----------------------------------*/

typedef struct tag_binr_timezone_setup_pkt{
        br_byte             pktid;
        union{
          struct{
            br_short_short  hour_bias;
            br_short_short  minutes_bias;          
          };
          binr_timezone_info tz_info;
        };
} binr_timezone_setup_pkt;

/*-----------------------------------*/

typedef struct tag_binr_datetime{
        br_dword            seconds;
        br_byte             day;
        br_byte             month;
        br_word             year;
        union{
          struct{
            br_short_short  hour_bias;
            br_short_short  minutes_bias;          
          };
          binr_timezone_info tz_info;
        };
} binr_datetime;

/*-----------------------------------*/

typedef struct tag_binr_datetime_pkt{
        br_byte             pktid;
        union{
          struct{
             br_dword       seconds;
             br_byte        day;
             br_byte        month;
             br_word        year;
             union{
               struct{
                 br_short_short hour_bias;
                 br_short_short minutes_bias;          
               };
               binr_timezone_info tz_info;
             };
          };
          binr_datetime     datetime;
        };
} binr_datetime_pkt;

/*----------------------------------------------------------------------------*/
/* Forecast data */
/* ������ �������� */
#define BINR_FORECAST                               0x52
#define BINR_FORECAST_REQUEST                       0x24
#define BINR_FORECAST_RESPONSE                      0x52

/* int on_forecast(int len, const binr_forecast_pkt* pkt); */
#define HANDLE_BINR_FORECAST(buf, len, fn) \
                    (fn)((len), (const binr_forecast_pkt*)(buf))

typedef binr_rate_pkt binr_forecast_rate_pkt;

/*-----------------------------------*/

typedef struct tag_binr_sat_forecast{
        union{
          struct{
                 br_byte    sat_system;  /* BINR_SATSYS_*    */
                 br_byte    sat_number;  /* 1-32    */
                };
          binr_satellite    sat;
         };
        br_byte             liter;      /* 255 fro gps */
        br_byte             azimuth;
        br_word             elevation;
        union{
          br_byte           ss;
          br_byte           signal_strength;
         };  

} binr_sat_forecast;

/*-----------------------------------*/

typedef struct tag_binr_forecast_pkt{
        br_byte             pktid;
        binr_sat_forecast   forecast[64];

} binr_forecast_pkt;

/*----------------------------------------------------------------------------*/
/* Digitalized second time label */
/* ��������� ��������� ����� ������� */
#define BINR_DSTIMELABEL                            0x53
#define BINR_DSTIMELABEL_REQUEST                    0x25
#define BINR_DSTIMELABEL_RESPONSE                   0x53

/* int on_dstimelabel(int len, const binr_dstimelabel_pkt* pkt); */
#define HANDLE_BINR_DSTIMELABEL(buf, len, fn) \
                    (fn)((len), (const binr_dstimelabel_pkt*)(buf))

typedef binr_rate_pkt binr_dstimelabel_rate_pkt;

/*-----------------------------------*/

typedef struct tag_binr_dstimelabel{
        br_long_double      time;
        br_short            week;
        br_float            freq_dev;   /* Average freq deviation */
        br_byte             new_obs_tag; /* new observation tag */
} binr_dstimelabel;

typedef struct tag_binr_dstimelabel_pkt{
        br_byte             pktid;
        union{
          struct{
            br_long_double  time;
            br_short        week;
            br_float        freq_dev;   /* Average freq deviation */
            br_byte         new_obs_tag; /* new observation tag */
          };
          binr_dstimelabel  timelabel;
        };
} binr_dstimelabel_pkt;



/*----------------------------------------------------------------------------*/
/* Link test */
/* �������� ������� ����� */
#define BINR_LINKTEST                               0x54
#define BINR_LINKTEST_REQUEST                       0x26
#define BINR_LINKTEST_RESPONSE                      0x54

/* int on_linktest(int len, const binr_linktest_response_pkt* pkt); */
#define HANDLE_BINR_LINKTEST(buf, len, fn) \
                    (fn)((len), (const binr_linktest_response_pkt*)(buf))
#define HANDLE_BINR_LINKTEST_RESPONSE(buf, len, fn) \
                    HANDLE_BINR_LINKTEST(buf, len, fn)

/*----------------------------------------------------------------------------*/
/* State vector */
/* �������� ������� ��������� */
#define BINR_STATE_VECTOR                            0x88
#define BINR_STATE_VECTOR_REQUEST                    0x27
#define BINR_STATE_VECTOR_RESPONSE                   0x88

/* int on_state_vector(int len, const binr_statevector_pkt* pkt); */
#define HANDLE_BINR_STATE_VECTOR(buf, len, fn) \
                    (fn)((len), (const binr_statevector_pkt*)(buf))
#define HANDLE_BINR_STATE_VECTOR_RESPONSE(buf, len, fn) \
                    HANDLE_BINR_STATE_VECTOR(buf, len, fn)

typedef binr_rate_pkt binr_statevector_rate_pkt;

/*-----------------------------------*/

typedef struct tag_binr_statevector{
        union{
          struct{
            br_double       latitude;
            br_double       longitude;
            br_double       height;
           };
          binr_coords       coords;
         };
        br_float            rms;

        br_long_double      time;
        br_word             week;

        union{
          struct{
            br_double       latitude_speed;
            br_double       longitude_speed;
            br_double       height_speed;
           };
          binr_coords       speed;
         };

        br_float            fsrc_deviation;
        br_byte             observation_state;  /* ������� ���������� */ 

} binr_statevector;


/*-----------------------------------*/

typedef struct tag_binr_statevector_pkt{
        br_byte             pktid;
        union{
          struct{
            union{
              struct{
                br_double   latitude;
                br_double   longitude;
                br_double   height;
               };
              binr_coords   coords;
             };
            br_float        rms;
    
            br_long_double  time;
            br_word         week;
    
            union{
              struct{
                br_double   latitude_speed;
                br_double   longitude_speed;
                br_double   height_speed;
               };
              binr_coords   speed;
             };
    
            br_float        fsrc_deviation;
            br_byte         observation_state;  /* ������� ���������� */ 
           };
          binr_statevector  statevector;
         };
} binr_statevector_pkt;


/*----------------------------------------------------------------------------*/
/* Phase meassurements */
/* ������� ��������� */
#define BINR_PHASEM_REQUEST                         0x28
#define BINR_PHASEM_RESPONSE1                       0x68
#define BINR_PHASEM_RESPONSE2                       0x69

typedef binr_rate_pkt binr_phasem_rate_pkt;


/*----------------------------------------------------------------------------*/
/* Ionosphere parameters */
/* ��������� ��������� */
#define BINR_IONOSPHERE                             0x4A
#define BINR_IONOSPHERE_REQUEST                     0x2A
#define BINR_IONOSPHERE_RESPONSE                    0x4A

/* int on_ionosphere(int len, const binr_ionosphere_pkt* pkt); */
#define HANDLE_BINR_IONOSPHERE(buf, len, fn) \
                    (fn)((len), (const binr_ionosphere_pkt*)(buf))
#define HANDLE_BINR_IONOSPHERE_RESPONSE(buf, len, fn) \
                    HANDLE_BINR_IONOSPHERE(buf, len, fn) 

typedef binr_rate_pkt binr_ionosphere_rate_pkt;

/*-----------------------------------*/
#define BINR_IONOSPHERE_RELIABLE        255

typedef struct tag_binr_ionosphere_params{
        br_float            A0;
        br_float            A1;
        br_float            A3;
        br_float            A4;
        br_float            B1;
        br_float            B2;
        br_float            B3;
        br_float            B4;
        br_byte             reliability; /* BINR_IONOSPHERE_RELIABLE */
} binr_ionosphere_params, binr_ionosphere;

/*-----------------------------------*/

typedef struct tag_binr_ionosphere_pkt{
        br_byte             pktid;
        union{
          struct{
            br_float        A0;
            br_float        A1;
            br_float        A3;
            br_float        A4;
            br_float        B1;
            br_float        B2;
            br_float        B3;
            br_float        B4;
            br_byte         reliability; /* BINR_IONOSPHERE_RELIABLE */
           };
          binr_ionosphere   ionosphere;
         };
} binr_ionosphere_pkt;


/*----------------------------------------------------------------------------*/
/* UTC & UTC(SU) time scale deviation */
/* ���������� ���� ������� UTC & UTC(SU) */
#define BINR_UTCDEVIATION                           0x4B
#define BINR_UTCDEVIATION_REQUEST                   0x2B
#define BINR_UTCDEVIATION_RESPONSE                  0x4B

/* int on_utcdeviation(int len, const binr_utcdeviation_pkt* pkt); */
#define HANDLE_BINR_UTCDEVIATION(buf, len, fn) \
                    (fn)((len), (const binr_utcdeviation_pkt*)(buf))
#define HANDLE_BINR_UTCDEVIATION_RESPONSE(buf, len, fn) \
                    HANDLE_BINR_UTCDEVIATION(buf, len, fn)

typedef binr_rate_pkt binr_utcdeviation_rate_pkt;

/*-----------------------------------*/
#define BINR_UTCDEVIATION_RELIABLE           255

typedef struct tag_binr_utcdeviation{
        br_double           A1;
        br_double           A0;
        br_long             t0;
        br_short            WNt;
        br_short            dtls;
        br_short            WNlsf;
        br_short            DN;
        br_short            dtlsf;
        br_byte             gps_reliability;
        br_short            Na;
        br_double           glonass_correction;
        br_byte             glonass_reliability;        
} binr_utcdeviation;

/*-----------------------------------*/

typedef struct tag_binr_utcdeviation_pkt{
        br_byte             pktid;
        union{
          struct{
            br_double       A1;
            br_double       A0;
            br_long         t0;
            br_short        WNt;
            br_short        dtls;
            br_short        WNlsf;
            br_short        DN;
            br_short        dtlsf;
            br_byte         gps_reliability;
            br_short        Na;
            br_double       glonass_correction;
            br_byte         glonass_reliability;        
           };
          binr_utcdeviation utcdev;
         };
} binr_utcdeviation_pkt;


/*----------------------------------------------------------------------------*/
/* Internal statistic */
/* ���������� ���������� */
#define BINR_INTSTAT_SETUP                          0x30
#define BINR_INTSTAT                                0x44

/* int on_internal_stat(int len, const binr_internal_stat_pkt* pkt); */
#define HANDLE_BINR_INTSTAT(buf, len, fn) \
                    (fn)((len), (const binr_internal_stat_pkt*)(buf))


#define BINR_INTSTAT_PAUSE                   0
#define BINR_INTSTAT_CONTINUE                1

#define BINR_INTSTAT_CONTTYPE_CONTINUE       0
#define BINR_INTSTAT_CONTTYPE_RESET          1


typedef struct tag_binr_internal_stat_setup{
        br_byte             rate;
        br_byte             pause;              /* BINR_INTSTAT_* */
        br_byte             cont_type;          /* BINR_INTSTAT_CONTTYPE_* */
        br_byte             observation_period;
} binr_internal_stat_setup;

/*-----------------------------------*/

typedef struct tag_binr_internal_stat_setup_pkt{
        br_byte             pktid;
        union{
          struct{
            br_byte         rate;
            br_byte         pause;              /* BINR_INTSTAT_* */
            br_byte         cont_type;          /* BINR_INTSTAT_CONTTYPE_* */
            br_byte         observation_period;
           };
          binr_internal_stat_setup stat;
         };
} binr_internal_stat_setup_pkt;

/*-----------------------------------*/

typedef struct tag_binr_internal_stat{
        br_byte             pause;              /* BINR_INTSTAT_* */
        br_byte             rate;
        br_word             quantity;
        br_double           latitude_exp;       /* Expectations */
        br_double           longitude_exp;  
        br_double           height_exp;  
        br_double           coords_rms;  
        br_double           height_rms;  
        br_double           speed_rms;  
} binr_internal_stat;

/*-----------------------------------*/

typedef struct tag_binr_internal_stat_pkt{
        br_byte             pktid;
        union{
          struct{
            br_byte         pause;              /* BINR_INTSTAT_* */
            br_byte         rate;
            br_word         quantity;
            br_double       latitude_exp;       /* Expectations */
            br_double       longitude_exp;  
            br_double       height_exp;  
            br_double       coords_rms;  
            br_double       height_rms;  
            br_double       speed_rms;  
           };
          binr_internal_stat stat;
         };
} binr_internal_stat_pkt;


/*----------------------------------------------------------------------------*/
/* Last decision */
/* ��������� ������� */
#define BINR_LAST_DECISION                           0x84
#define BINR_LAST_DECISION_REQUEST                   0x37
/*#define BINR_LASTDECISION_RESPONSE                  0x84*/
#define BINR_LAST_DECISION_RESPONSE2                 BINR_WASPEED_RESPONSE

/* int on_last_decision(int len, const binr_decision_pkt* pkt); */
#define HANDLE_BINR_LAST_DECISION(buf, len, fn) \
                    (fn)((len), (const binr_decision_pkt*)(buf))



typedef binr_rate_pkt binr_decision_rate_pkt;

/*-----------------------------------*/

typedef struct tag_binr_decision{
        union{
          binr_coords       coords;
          struct{
                 br_double  latitude;
                 br_double  longitude;
                 br_double  height;
                };
             };
        br_dword            time;
        br_long_double      rms;
} binr_decision;


/*-----------------------------------*/

typedef struct tag_binr_decision_pkt{
        br_byte             pktid;
        union{
          struct{
            union{
              binr_coords   coords;
              struct{
                     br_double latitude;
                     br_double longitude;
                     br_double height;
                    };
                 };
            br_dword        time;
            br_long_double  rms;
           };
          binr_decision     decision;
         };
} binr_decision_pkt;


/*----------------------------------------------------------------------------*/
/* Current coordinates */
/* ������ ������� ��������� */
#define BINR_CURCOORDS                               0x85
#define BINR_CURCOORDS_REQUEST                       0x38
#define BINR_CURCOORDS_RESPONSE                      0x85
#define BINR_CURCOORDS_RESPONSE2                     BINR_WASPEED_RESPONSE

/* int on_curcoords(int len, const binr_curcoords_pkt* pkt); */
#define HANDLE_BINR_CURCOORDS(buf, len, fn) \
                    (fn)((len), (const binr_curcoords_pkt*)(buf))


typedef binr_rate_pkt binr_curcoords_rate_pkt;

/*-----------------------------------*/

typedef struct tag_binr_curcoords{
        union{
          binr_coords       coords;
          struct{
                 br_double  latitude;
                 br_double  longitude;
                 br_double  height;
                };
             };
        br_dword            time;
        br_long_double      rms;
} binr_curcoords;


/*-----------------------------------*/

typedef struct tag_binr_curcoords_pkt{
        br_byte             pktid;
        union{
          struct{
            union{
              binr_coords   coords;
              struct{
                     br_double latitude;
                     br_double longitude;
                     br_double height;
                    };
                 };
            br_dword        time;
            br_long_double  rms;
           };
          binr_curcoords    curcoords;
         };
} binr_curcoords_pkt;


/*----------------------------------------------------------------------------*/
/* Receiver unit extended information */
/* ����������� ���������� � ��������� ��� */
#define BINR_RUESTATE                               0x87
#define BINR_RUESTATE_REQUEST                       0x39
#define BINR_RUESTATE_RESPONSE                      0x87

/* int on_ruestate(int len, const binr_ruestate_pkt* pkt); */
#define HANDLE_BINR_RUESTATE(buf, len, fn) \
                    (fn)((len), (const binr_ruestate_pkt*)(buf))


typedef binr_rate_pkt binr_ruestate_rate_pkt;

/*-----------------------------------*/

typedef struct tag_binr_ruestate_pkt{
        br_byte             tmp;
} binr_ruestate_pkt;


/*----------------------------------------------------------------------------*/
/* Group Delay Time correction */
/* ��������� ��� */
#define BINR_GDTCORRECTION                          0x97
#define BINR_GDTCORRECTION_REQUEST                  0x96
#define BINR_GDTCORRECTION_SETUP                    0x96
#define BINR_GDTCORRECTION_RESPONSE                 0x97

/* int on_gtdcorrection(int len, const binr_gdt* pkt); */
#define HANDLE_BINR_GDTCORRECTION(buf, len, fn) \
                    (fn)((len), (const binr_gdt*)(buf))


typedef struct tag_binr_gdt_setup{
        br_float            gdt[23];
} binr_gdt_setup;

/*-----------------------------------*/

typedef struct tag_binr_gdt_setup_pkt{
        br_byte             pktid;
        union{
          struct{
            br_float        gdt[23];
           };
          binr_gdt_setup    gdt_struct;
         };
} binr_gdt_setup_pkt;

/*-----------------------------------*/

typedef struct tag_binr_gdt_pair{
        br_float            const_part;
        br_float            var_part;
} binr_gdt_pair;

/*-----------------------------------*/

typedef struct tag_binr_gdt{
        binr_gdt_pair       gdt[23];
} binr_gdt;

/*-----------------------------------*/

typedef struct tag_binr_gdt_pkt{
        br_byte             pktid;
        union{
          struct{
            binr_gdt_pair   gdt[23];
           };
          binr_gdt          gdt_struct;
         };
} binr_gdt_pkt;


/*-----------------------------------*/


#ifdef WIN32
#include <poppack.h>
#endif


#endif /* BINR_H */
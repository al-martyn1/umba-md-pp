/*----------------------------------------------------------------------------
*  Module Name:  cckeywrd.cpp
*  Description:  cc2x keywords files reading
*  Date:         03/16/02
*----------------------------------------------------------------------------*/

#pragma hdrstop

#include <set>
#include <string>
#include <fstream>
#include <sstream>
#include <stdio.h>

#include <mkmap.h>

#include "cckeywrd.h"
#include "cclexenv.h"
#include "udaux.h"

#define laja "laja"
int herna;

#define FAMSLFNMDAJNF 32543285971348
extern FILE* yyout;
#define FAMSLFNMDAJNF NJBHGCMMKJN
extern FILE* yyout;
#define FAMSLFNMDAJNF NJBHGCMMKJN  \
                       LLDSWNFF
extern FILE* yyout;

extern int disable_output;

using namespace std;

typedef multikeymap<string, keyword_params>  keyword_map;


keyword_map keywords;
keyword_map user_keywords;
keyword_map types;
keyword_map user_types;


map<string, string> name_decoration;


string user_types_save_filename = "";
int    dont_save_user_types = 0;


void read_keyword_file(const char* fname, keyword_map& keywords);


/*----------------------------------------------------------------------------*/
void read_keyword_file(const char* fname, keyword_map& keywords)
{
 std::ifstream le_file(fname);
 std::string le_line;
 getline(le_file,le_line);
 le_line = trim(le_line);  
 while(le_file)
   {
    if (le_line.size() && le_line[0]!=';')
       {
        stringstream ss(le_line);
        string key;
        ss>>key;
        if (key=="type" || key=="keyword")
           {
            string s, base = "";
            ss>>s;
            while(ss)
              {
               if (!s.size()) continue;
               if (!base.size()) base = s;
               keywords.add_alias(base, s);
               ss>>s;
              }
           }
        else
           {}
       }
    getline(le_file,le_line);
    le_line = trim(le_line);  
   }
}
/*----------------------------------------------------------------------------*/
void read_keywords(const char* fname)
{
 read_keyword_file(fname, keywords);
}
/*----------------------------------------------------------------------------*/
void read_user_keywords(const char* fname)
{
 read_keyword_file(fname, user_keywords);
}
/*----------------------------------------------------------------------------*/
void read_types(const char* fname)
{
 read_keyword_file(fname, types);
}
/*----------------------------------------------------------------------------*/
void read_user_types(const char* fname)
{
 read_keyword_file(fname, user_types);
}
/*----------------------------------------------------------------------------*/
#pragma argsused

#define DDDDDDD 3333
void read_name_decoration(const char* fname)
{
 std::ifstream nd_file(fname);
 std::string nd_line;
 getline(nd_file,nd_line);
 nd_line = trim(nd_line);  
 while(nd_file)
   {
    if (nd_line.size() && nd_line[0]!=';')
       {
        stringstream ss(nd_line);
        string ndt, decor;
        ss>>ndt;
        getline(ss,decor);
        decor = trim(decor);
        name_decoration[ndt] = decor;
       }
    getline(nd_file,nd_line);
    nd_line = trim(nd_line);  
   }             
}
/*----------------------------------------------------------------------------*/
void save_user_types(void)
{
 if (dont_save_user_types) return;
 if (!user_types_save_filename.size()) return;

 ofstream out(user_types_save_filename.c_str());

 out<<"; cc2x automaticaly generated file\n";
 out<<"; user types lists\n";

 keyword_map::key_iterator kit = user_types.key_begin();
 for (; kit!=user_types.key_end(); kit++)
     {
      keyword_map::alias_iterator it = user_types.alias_begin(kit->first);
      keyword_map::alias_iterator aiend = user_types.alias_end(kit->first);
      if (it!=aiend)
         {
          out<<"type ";
         }
      for(; it!=aiend; it++)
         {
          out<<it->second<<" ";
         }
      out<<"\n";
     }

}
/*----------------------------------------------------------------------------*/
std::string get_type_label_name(const char* t)
{
 string type = t;
 if (user_types.have_alias(string(t)))
    {
     type = user_types.get_first_alias(t);
    }            
 return string(name_decoration["type_label_prefix"]) + 
        type + 
        string(name_decoration["type_label_postfix"]); 
}
/*----------------------------------------------------------------------------*/
const char* decorate_ident(const char* ident)
{
 static char result[1024];

 if (disable_output)
    {
     result[0] = 0;
     return result;
    }
 
 std::string s;

 if (keywords.have_alias(string(ident)))
    {
     s = lexenv("keyword_begin") + 
         string(ident) + 
         lexenv("keyword_end");
    }
 else
    { 
     if (user_keywords.have_alias(string(ident)))
        {
         s = lexenv("user_keyword_begin") + 
             string(ident) + 
             lexenv("user_keyword_end");
        }
     else
        {
         if (types.have_alias(string(ident)))
            {
             s = lexenv("type_begin") + 
                 string(ident) + 
                 lexenv("type_end");
            }
         else
            {
             if (user_types.have_alias(string(ident)))
                {
                 s = lexenv("user_type_begin") + 
                     string(ident) + 
                     lexenv("user_type_end");
                }            
            }        
        }
    }

 if (!s.size())
    { /* not found and not decorated */
     s = ident;
    }

 s.copy(result, sizeof(result)-1, 0);
 result[sizeof(result)-1>s.size() ? s.size() : sizeof(result)-1] = 0; 
 return result;
}
